package com.ddc.bansoogi.common.util.health

data class CustomHealthData(
    var step: Long,
    var stepGoal: Int,
    var floorsClimbed: Float,
    var sleepData: Int,
)