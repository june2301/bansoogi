package com.ddc.bansoogi.common.navigation

object NavRoutes {
    const val HOME = "home"
    const val COLLECTION = "collection"
    const val CALENDAR = "calender"
    const val MYINFO = "myInfo"
    const val MYINFOUPDATE = "myInfoUpdate"
}