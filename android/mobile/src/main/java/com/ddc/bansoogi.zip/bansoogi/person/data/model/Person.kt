package com.ddc.bansoogi.person.data.model

class Person (
    val id: String,
    val name: String
)