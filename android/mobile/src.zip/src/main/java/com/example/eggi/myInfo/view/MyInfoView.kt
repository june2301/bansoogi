package com.example.eggi.myInfo.view

import com.example.eggi.myInfo.data.model.MyInfo

interface MyInfoView {
    fun displayMyInfo(myInfo: MyInfo)
}
