package com.example.eggi.person.data.model

class Person (
    val id: String,
    val name: String
)